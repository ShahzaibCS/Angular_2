Angular 2 Redit App
